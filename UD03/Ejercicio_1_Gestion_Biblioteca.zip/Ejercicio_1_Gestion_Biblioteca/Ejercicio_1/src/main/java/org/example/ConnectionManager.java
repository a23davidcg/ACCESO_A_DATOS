package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
    //Gestion de conexiones con la base de datos
    //Mediante el paatron singleton debemos de

    private static Connection conex;

    public static Connection getInstance() throws SQLException {
        if (conex!= null){
            conex = DriverManager.getConnection("jdbc:h2:C:\\Users\\David\\Downloads\\biblioteca\\biblioteca.trace.db");
        }
        return conex;
    }

}
