package Ejercicio_3_EditorTexto;

public class Editor {

    public static void main(String[] args) {
        Documento docu = new Documento();
        docu.readFile();
    }


}
