package Ejercicio_3_EditorTexto;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class Documento {

    private File arquivo;
    private String nombre;

    public Documento(String nombre) {
        this.nombre = nombre;
    }

    public Documento(File arquivo) {
        this.arquivo = arquivo;
    }

    public Documento() {
    }

    public boolean exists() {
        if (arquivo.exists() && arquivo != null) {
            return true;
        } else {
            return false;
        }
    }

    public String readFile() {

        try {
            ObjectInputStream ois = new ObjectInputStream(
                    new BufferedInputStream(
                            new FileInputStream("ProbasExercicio1.txt")));

            StringBuilder stringBuilder = new StringBuilder();
            ois.readObject(); //metemos o obxeto nun  stringbuilder

            System.out.println(stringBuilder);

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("ERROR, non se pode leer o arquivo ");
        }

        return null;
    }

    public String readFileNIO() throws IOException {

        if (exists()) {
            return Files.readString(arquivo.toPath());
        }
        return null;

    }

    public String writeFromString(String contenido) throws IOException {

        //Falta coller o que se lee para escribir no novo archivo

        //Recoger la cadena de caracteres.
        Scanner sc = new Scanner(System.in);
        String cadenaCaracteres = sc.nextLine();


        //Escribir en el fichero
        try (BufferedWriter bw = new BufferedWriter(
                new FileWriter("probasCopia.txt"))) {

            bw.write(cadenaCaracteres);

            System.out.println(contenido);

        }
        return contenido;
    }

    public String writeFromStringPrintWriter() throws IOException {


        try {
            PrintWriter pw = new PrintWriter(writeFromString(String.valueOf(Paths.get("probasCopia.txt"))));


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public String writeFromInputStream() {
        try {
            ObjectInputStream ois = new ObjectInputStream(
                    new BufferedInputStream(
                            new FileInputStream(String.valueOf(Paths.get("probasCopia.txt")))));
            System.out.println(ois);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }


    public String writeFromKeyBoard() {
        return writeFromKeyBoard();
    }

    public Object getFile(Documento arquivo) {
        return arquivo;
    }

    @Override
    public String toString() {
        return "Documento{" +
                "arquivo=" + arquivo +
                ", nombre='" + nombre + '\'' +
                '}';
    }
}






