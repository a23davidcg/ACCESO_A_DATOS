package org.example;

public class Main {
    public static void main(String[] args) {

        EstadisticasDAO.contadorDeLineas();

        EstadisticasDAO.contadorDeEspacios();

        EstadisticasDAO.existe();

        EstadisticasDAO.ultimaModificacion();

        EstadisticasDAO.getRuta();




    }
}