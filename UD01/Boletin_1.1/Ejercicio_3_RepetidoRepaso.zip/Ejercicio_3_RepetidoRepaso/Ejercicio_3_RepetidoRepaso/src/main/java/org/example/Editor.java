package org.example;

public class Editor {
}
