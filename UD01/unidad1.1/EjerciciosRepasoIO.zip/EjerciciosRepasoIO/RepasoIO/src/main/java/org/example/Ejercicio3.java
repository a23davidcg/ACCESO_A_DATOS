package org.example;

public class Ejercicio3 {
    public static void main(String[] args) {

    }
}
