package SerializacionYDeserializacion;

public class Grupo {
}
