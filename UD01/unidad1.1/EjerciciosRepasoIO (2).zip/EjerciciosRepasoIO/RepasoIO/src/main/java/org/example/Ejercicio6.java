package org.example;

public class Ejercicio6 {
    public static void main(String[] args) {

    }
}
