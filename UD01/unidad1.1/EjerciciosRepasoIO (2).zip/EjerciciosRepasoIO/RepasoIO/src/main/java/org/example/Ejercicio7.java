package org.example;

public class Ejercicio7 {
    public static void main(String[] args) {

    }

}
