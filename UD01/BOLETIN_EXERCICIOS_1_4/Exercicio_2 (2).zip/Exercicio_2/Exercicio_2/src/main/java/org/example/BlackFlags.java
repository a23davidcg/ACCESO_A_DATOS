package org.example;

public enum BlackFlags {
   nfsw,
    religious,
    political,
    racist,
    sexist,
    explicit
}
