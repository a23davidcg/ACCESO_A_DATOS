package local.exame.ad.ficheros.gson;

public class AppResultados {

    public static final String RESULTADOS_JSON_FILE = "C:\\Users\\dam2ad\\Desktop\\partidos.json";
    public static final String RESULTADOS_TXT_FILE = "C:\\Users\\dam2ad\\Desktop\\partidos.txt";
    public static final String RESULTADOS_OBJECT_FILE = "C:\\Users\\dam2ad\\Desktop\\partidos.dat";

    public static void main(String[] args) {


    }
}
